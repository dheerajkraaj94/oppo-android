<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/insomnia/index.ts#L1">
  Improve this doc
</a>

# Insomnia

```
$ ionic cordova plugin add cordova-plugin-insomnia
$ npm install --save @ionic-native/insomnia
```

## [Usage Documentation](https://ionicframework.com/docs/native/insomnia/)

Plugin Repo: [https://github.com/EddyVerbruggen/Insomnia-PhoneGap-Plugin](https://github.com/EddyVerbruggen/Insomnia-PhoneGap-Plugin)

Prevent the screen of the mobile device from falling asleep.

## Supported platforms
- Android
- Browser
- Firefox OS
- iOS
- Windows
- Windows Phone 8



