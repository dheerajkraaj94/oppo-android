<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/streaming-media/index.ts#L46">
  Improve this doc
</a>

# Streaming Media

```
$ ionic cordova plugin add cordova-plugin-streaming-media
$ npm install --save @ionic-native/streaming-media
```

## [Usage Documentation](https://ionicframework.com/docs/native/streaming-media/)

Plugin Repo: [https://github.com/nchutchind/cordova-plugin-streaming-media](https://github.com/nchutchind/cordova-plugin-streaming-media)

This plugin allows you to stream audio and video in a fullscreen, native player on iOS and Android.

## Supported platforms
- Amazon Fire OS
- Android
- iOS



