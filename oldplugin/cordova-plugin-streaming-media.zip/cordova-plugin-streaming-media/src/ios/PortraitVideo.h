#import <Foundation/Foundation.h>
#import <AVKit/AVKit.h>

@interface PortraitAVPlayerViewController: AVPlayerViewController
{
    
}
@end
