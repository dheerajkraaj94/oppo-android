import PDFJSWorker from "worker-loader!pdfjs-dist/build/pdf.worker.js";
import pdfjsLib from "pdfjs-dist";
import _ from "lodash";
class PdfViewer{
    constructor(path, tabId){
        
        var vielodash;
        this.url = path;
        this.tabId = tabId;
        // this.pdfjsLib.disableWorker = true;
        pdfjsLib.GlobalWorkerOptions.workerPort = new PDFJSWorker();
        
        this.pdfDoc = null,
        this.pageNum = 1,
        this.pageRendering = false,
        this.pageNumPending = null,
        this.dimension = 1.2,
        this.documentCanvas = document.getElementById("document"+this.tabId),
        this.ctx = this.documentCanvas.getContext("2d"),
        //this.myp = null;
        this.totalPages = 0;
        this.initilize();
        this.viewport = [];
    }
    
    initilize(){
        var self = this;
        this.pdfjsLib.getDocument(this.url).then(function(pdfDoc_) {
            self.pdfDoc = pdfDoc_;
            self.totalPages = self.pdfDoc.numPages;
            self.renderPage(self.pageNum).then(function(){
                //lecture.getStatusFromInitiatorForViewer();
            });
        });
    };

    renderPage(num) {
        return new Promise((resolve, reject) => {
            var self = this;
            self.pageRendering = true;
            // Using promise to fetch the page
            self.pdfDoc.getPage(num).then(function(page) {
                console.log(self.documentCanvas.width);
                self.viewport = page.getViewport(self.documentCanvas.width / page.getViewport(1.0).width);
                //var viewport = page.getViewport(self.dimension);
                self.documentCanvas.height = self.viewport.height;
                self.documentCanvas.width = self.viewport.width;
    
                // Render PDF page into canvas context
                var renderContext = {
                    canvasContext: self.ctx,
                    viewport: self.viewport
                };
                var renderTask = page.render(renderContext);
    
                // Wait for rendering to finish
                renderTask.promise.then(function() {
                    // if (!self.myp) {
                    //     self.myp = new p5(sketch, "main"+self.tabId);
                    //     self.myp.width = self.viewport.width;
                    //     self.myp.height = self.viewport.height;
                    //     self.myp.setup();
                    // }
                    self.pageRendering = false;
                    if (self.pageNumPending !== null) {
                        // New page rendering is pending
                        self.renderPage(self.pageNumPending);
                        self.pageNumPending = null;
                    }
                    resolve();
                }).catch(function(e){
                    console.log(e);
                    self.pageRendering = false;
                });
            });
        });
    }

    reRenderPage(){
        var self = this;
        var num  = this.pageNum;
        return new Promise((resolve, reject) => {
            self.pageRendering = true;
            // Using promise to fetch the page
            self.pdfDoc.getPage(num).then(function(page) {
                console.log(self.documentCanvas.width);
                self.viewport = page.getViewport(self.documentCanvas.width / page.getViewport(1.0).width);
                //var viewport = page.getViewport(self.dimension);
                self.documentCanvas.height = self.viewport.height;
                self.documentCanvas.width = self.viewport.width;

                // Render PDF page into canvas context
                var renderContext = {
                    canvasContext: self.ctx,
                    viewport: self.viewport
                };
                var renderTask = page.render(renderContext);

                // self.myp.resizeCanvas(self.viewport.width, self.viewport.height);
                // self.myp.syncCanvas();
                // self.myp.redraw();
                // Wait for rendering to finish
                renderTask.promise.then(function() {
                    self.pageRendering = false;
                    resolve(self.viewport);                   
                });

            });
            // Update page counters
            document.getElementById("page_num"+self.tabId).textContent = num;
        });
    }

    queueRenderPage(num) {
        if (viewer.pageRendering) {
            viewer.pageNumPending = num;
        } else {
            viewer.renderPage(num);
        }
    }

    onPageChange(pageNumber, drawing){
        viewer.pageNum = pageNumber;
        // viewer.myp.page = viewer.pageNum;
        // viewer.myp.drag = [];
        // viewer.myp.drawing = drawing;
        // viewer.myp.saveDrawing(pageNumber);
        // // viewer.myp.drawings = drawings;
        // viewer.myp.clear();
        // viewer.myp.syncCanvas();
        viewer.queueRenderPage(viewer.pageNum);
    }

    onFirstStatus(pageNumber, drawing, drawings, color){
        viewer.pageNum = pageNumber;
		// if(viewer.myp == undefined){
		// 	setTimeout(function(){
		// 		 window.viewer.onFirstStatus(pageNumber, drawing, drawings, color);
		// 	},1000);
		// }
        // viewer.myp.page = viewer.pageNum;
        // viewer.myp.drag = [];
        // viewer.myp.drawing = drawings;
        // viewer.myp.drawingColor = color;
        // viewer.myp.saveDrawing(pageNumber);
        // // viewer.myp.drawings = drawings;
        // viewer.myp.clear();
        // viewer.myp.syncCanvas();
        // viewer.myp.drawing = drawing;
        // viewer.myp.redraw();
        viewer.queueRenderPage(viewer.pageNum);
    }
};


//P5 Canvas Element
var sketch = function (p) {
    p.drag = [];
    p.drawing = [];
    p.drawings = [];
    p.currentPath = [];
    p.isDrawing = false;
    p.page = 1;
    p.width = viewer.viewport.width;
    p.height = viewer.viewport.height;
    p.disableFriendlyErrors = true;
    p.drawingColor = 'rgb(255, 0, 0)';

    p.setup = function () {
        var canvas = p.createCanvas(p.width, p.height);

        canvas.style('z-index:99');
        canvas.position(0, 0);
        

        p.frameRate(30);
        p.strokeWeight(1.5);
        p.noFill();
        p.stroke(p.drawingColor);
        p.noLoop();
    }

    p.draw = function () {        
        for (var i = 0; i < p.drawing.length; i++) {
            var path = p.drawing[i];
            p.stroke(path.color);
            p.beginShape();
            for (var j = 0; j < path.vt.length; j++) {
                p.curveVertex(path.vt[j].x*p.width, path.vt[j].y*p.height);
            }
            p.endShape();
        }

        p.stroke(p.drawingColor);
        p.beginShape();
        var path = p.drag;
        for (var k = 0; k < path.length; k++) {
            p.curveVertex(path[k].x*p.width, path[k].y*p.height);
        }
        p.endShape();
    }

    p.mDragged = function(data){
        p.drag.push(data);
        p.clear();
        p.redraw();
    }

    p.saveDrawing = function (page) {
        if (p.drawing.length > 0) {
            var obj = p.drawings.find(function (obj) { return obj.page === p.page; });
            if (obj) {
                for (var k = 0; k < p.drawing.length; k++) {
                    obj.drawing.push(p.drawing[k]);
                }
            } else {
                var data = {
                    page: page,
                    drawing: p.drawing
                }
                p.drawings.push(data);
            }
            p.drawing = [];
            p.drag = [];
        }
    }

    p.syncCanvas = function () {
        var obj = p.drawings.find(function (obj) { return obj.page === p.page; });
        if (obj) {
            var draw = obj.drawing;
            p.clear();
            for (var i = 0; i < draw.length; i++) {
                var path = draw[i];
                p.stroke(path.color);
                p.beginShape();
                for (var j = 0; j < path.vt.length; j++) {
                    p.curveVertex(path.vt[j].x*p.width, path.vt[j].y*p.height);
                }
                p.endShape();
            }
        }
    }

    p.clearDrawing = function(){
        p.drawing = [];
        p.drag = [];
        var index = _.findIndex(p.drawings, function(obj) { 
            return obj.page === p.page; 
        });
        if(index >= 0){
            p.drawings.splice(index,1);
        }
        p.clear();
    }

    p.changeColor = function(color){
        p.drawingColor = color;
        p.drag = [];
        p.stroke(color);
    }

    p.undo = function(index){
        if(p.drawing.length<=0){
            return false; 
        }else{
            p.drag = [];
            if(index >= 0){
                p.drawing.splice(index,1);
            }
            p.clear();
            p.syncCanvas();
            p.redraw();
            return true;
        }
    }

    p.drawingStopped = function(){
        if(p.drag.length > 0){
            p.drawing.push({'color': p.drawingColor, vt:p.drag });
            p.drag = [];  
            p.redraw();     
        }
    }
    
    p.resetArea = function(width, height){
        p.resizeCanvas(width,height);
    }
}